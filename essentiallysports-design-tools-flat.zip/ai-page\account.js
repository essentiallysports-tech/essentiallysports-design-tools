function closeProfileMenu() {
  const profileMenu = document.getElementById('profile-menu');
  const profileTrigger = document.getElementById('profile-trigger');
  profileMenu?.classList.remove('is-open');
  profileTrigger?.setAttribute('aria-expanded', 'false');
}

function closeNavMenus(exceptMenu = null) {
  document.querySelectorAll('.nav-dropdown').forEach(menu => {
    if (menu === exceptMenu) return;
    menu.classList.remove('is-open');
    menu.querySelector('.nav-trigger')?.setAttribute('aria-expanded', 'false');
  });
}

function setupHeaderMenus() {
  const profileMenu = document.getElementById('profile-menu');
  const profileTrigger = document.getElementById('profile-trigger');

  profileTrigger?.addEventListener('click', event => {
    event.preventDefault();
    event.stopPropagation();
    closeNavMenus();
    const isOpen = profileMenu.classList.toggle('is-open');
    profileTrigger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
  });

  document.querySelectorAll('.nav-dropdown').forEach(menu => {
    const trigger = menu.querySelector('.nav-trigger');
    if (!trigger) return;

    menu.addEventListener('mouseenter', () => {
      if (window.matchMedia('(max-width: 820px)').matches) return;
      closeProfileMenu();
      closeNavMenus(menu);
      menu.classList.add('is-open');
      trigger.setAttribute('aria-expanded', 'true');
    });

    trigger.addEventListener('click', event => {
      if (!window.matchMedia('(max-width: 820px)').matches) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      closeProfileMenu();
      const isOpen = menu.classList.contains('is-open');
      closeNavMenus();
      menu.classList.toggle('is-open', !isOpen);
      trigger.setAttribute('aria-expanded', isOpen ? 'false' : 'true');
    });
  });

  document.addEventListener('click', event => {
    if (!event.target.closest('.nav-dropdown')) closeNavMenus();
    if (!event.target.closest('.profile-menu')) closeProfileMenu();
  });
}

function setupPageTransitions() {
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const showPageBody = () => {
    document.body.classList.remove('is-page-leaving');
    document.body.classList.add('is-page-ready');
  };

  requestAnimationFrame(showPageBody);
  window.addEventListener('pageshow', showPageBody);

  document.addEventListener('click', event => {
    const link = event.target.closest('a[href]');
    if (!link || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    if (link.target && link.target !== '_self') return;
    if (link.hasAttribute('download')) return;

    const href = link.getAttribute('href');
    if (!href || href.startsWith('#') || /^(?:mailto:|tel:|javascript:)/i.test(href)) return;

    const url = new URL(href, window.location.href);
    if (url.origin !== window.location.origin) return;
    if (url.pathname === window.location.pathname && url.search === window.location.search) return;

    event.preventDefault();
    if (prefersReducedMotion) {
      window.location.href = url.href;
      return;
    }

    document.body.classList.remove('is-page-ready');
    document.body.classList.add('is-page-leaving');
    setTimeout(() => {
      window.location.href = url.href;
    }, 220);
  });
}

function loadProfile() {
  try {
    return JSON.parse(localStorage.getItem('es.ai.profile') || '{}');
  } catch (error) {
    return {};
  }
}

function saveProfile(profile) {
  localStorage.setItem('es.ai.profile', JSON.stringify(profile));
}

function cleanVisitorName(value) {
  return String(value || '').replace(/\s+/g, ' ').trim();
}

function nameFromEmail(email) {
  const localPart = String(email || '').split('@')[0];
  if (!localPart) return '';
  return localPart.replace(/[._-]+/g, ' ').replace(/\b\w/g, char => char.toUpperCase()).trim();
}

function isDemoProfileName(name) {
  return /^suhail(?:\s+quraishi)?$/i.test(cleanVisitorName(name));
}

function getNetlifyIdentityUser() {
  try {
    return window.netlifyIdentity?.currentUser?.() || null;
  } catch (error) {
    return null;
  }
}

function inferVisitorProfile() {
  const stored = loadProfile();
  const params = new URLSearchParams(window.location.search);
  const queryName = cleanVisitorName(params.get('name') || params.get('full_name') || params.get('fullName') || params.get('user'));
  const queryEmail = cleanVisitorName(params.get('email'));
  const identityUser = getNetlifyIdentityUser();
  const metadata = identityUser?.user_metadata || identityUser?.app_metadata || {};
  const identityName = cleanVisitorName(metadata.full_name || metadata.fullName || metadata.name || identityUser?.user_metadata?.name);
  const identityEmail = cleanVisitorName(identityUser?.email);
  const storedName = cleanVisitorName(stored.name);
  const storedEmail = cleanVisitorName(stored.email);
  const name = queryName ||
    identityName ||
    (storedName && !isDemoProfileName(storedName) ? storedName : '') ||
    nameFromEmail(queryEmail || identityEmail || storedEmail) ||
    'Guest User';
  const avatar = stored.avatar || 'assets/profile-avatar-default.webp';
  if ((queryName || identityName || queryEmail || identityEmail) && name !== stored.name) {
    try {
      saveProfile({ ...stored, name, email: queryEmail || identityEmail || storedEmail });
    } catch (error) {}
  }
  return { ...stored, name, avatar };
}

function loadSettings() {
  try {
    return JSON.parse(localStorage.getItem('es.ai.settings') || '{}');
  } catch (error) {
    return {};
  }
}

function saveSettings(settings) {
  localStorage.setItem('es.ai.settings', JSON.stringify(settings));
}

function syncProfileChrome() {
  const profile = inferVisitorProfile();
  const name = profile.name;
  const avatar = profile.avatar || 'assets/profile-avatar-default.webp';
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('[data-profile-name]').forEach(el => {
    el.textContent = name;
  });
  document.querySelectorAll('[data-profile-initial]').forEach(el => {
    el.textContent = '';
    el.classList.add('has-image');
    el.style.backgroundImage = `url("${avatar}")`;
  });
  document.querySelectorAll('.profile-option').forEach(link => {
    const targetPage = (link.getAttribute('href') || '').split('/').pop();
    if (targetPage && targetPage === currentPage && currentPage !== 'index.html') {
      link.setAttribute('aria-current', 'page');
    } else {
      link.removeAttribute('aria-current');
    }
  });
}

setupPageTransitions();
setupHeaderMenus();
syncProfileChrome();
