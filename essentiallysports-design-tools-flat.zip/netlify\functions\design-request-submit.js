const crypto = require('crypto');

const SHEETS_SCOPE = 'https://www.googleapis.com/auth/spreadsheets';
const TOKEN_URL = 'https://oauth2.googleapis.com/token';

const HEADERS = [
  'Request ID',
  'Created At',
  'Status',
  'Request Type',
  'Requester Name',
  'Requester Email',
  'Department',
  'Publication',
  'Social Channel',
  'Sport',
  'Team or League',
  'Title',
  'Entities',
  'Brief',
  'Design Copy',
  'Reference Links',
  'Reference Files',
  'Additional Notes',
  'Priority',
  'Design Needed By',
  'Publish At',
  'Source',
];

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  };
}

function requiredConfig() {
  return {
    spreadsheetId: process.env.GOOGLE_SHEETS_ID,
    clientEmail: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
    privateKey: (process.env.GOOGLE_PRIVATE_KEY || '').replace(/\\n/g, '\n'),
    range: process.env.GOOGLE_SHEETS_RANGE || 'Sheet1!A:V',
  };
}

function base64Url(value) {
  return Buffer.from(value)
    .toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

function signJwt({ clientEmail, privateKey }) {
  const now = Math.floor(Date.now() / 1000);
  const header = { alg: 'RS256', typ: 'JWT' };
  const claim = {
    iss: clientEmail,
    scope: SHEETS_SCOPE,
    aud: TOKEN_URL,
    exp: now + 3600,
    iat: now,
  };
  const unsigned = `${base64Url(JSON.stringify(header))}.${base64Url(JSON.stringify(claim))}`;
  const signature = crypto.sign('RSA-SHA256', Buffer.from(unsigned), privateKey);
  return `${unsigned}.${base64Url(signature)}`;
}

async function getAccessToken(config) {
  const assertion = signJwt(config);
  const response = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion,
    }),
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.error_description || data.error || 'Google token request failed');
  }
  return data.access_token;
}

function list(value) {
  if (Array.isArray(value)) return value.join('\n');
  return value || '';
}

function files(value) {
  if (!Array.isArray(value)) return '';
  return value.map(file => file?.name || '').filter(Boolean).join('\n');
}

function toSheetRow(record) {
  return [
    record.id,
    record.createdAt,
    record.status,
    record.requestType,
    record.requester?.name,
    record.requester?.email,
    record.requester?.department,
    record.publication,
    record.socialChannel,
    record.sport,
    record.teamOrLeague,
    record.title,
    record.entities,
    record.brief,
    record.designCopy,
    list(record.referenceLinks),
    files(record.referenceFiles),
    record.additionalNotes,
    record.priority,
    record.designDueAt,
    record.publishAt,
    record.source,
  ].map(value => value ?? '');
}

async function appendToSheet(record, config) {
  const accessToken = await getAccessToken(config);
  const encodedRange = encodeURIComponent(config.range);
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${config.spreadsheetId}/values/${encodedRange}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`;
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      values: [toSheetRow(record)],
    }),
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.error?.message || 'Google Sheets append failed');
  }
  return data;
}

exports.handler = async event => {
  if (event.httpMethod !== 'POST') {
    return json(405, { ok: false, error: 'Method not allowed' });
  }

  const config = requiredConfig();
  if (!config.spreadsheetId || !config.clientEmail || !config.privateKey) {
    return json(200, {
      ok: false,
      skipped: true,
      reason: 'missing_google_sheets_config',
      requiredHeaders: HEADERS,
    });
  }

  try {
    const payload = JSON.parse(event.body || '{}');
    if (!payload.record?.id) {
      return json(400, { ok: false, error: 'Missing design request record' });
    }

    const result = await appendToSheet(payload.record, config);
    return json(200, {
      ok: true,
      updatedRange: result.updates?.updatedRange || null,
    });
  } catch (error) {
    return json(500, {
      ok: false,
      error: error.message || 'Unable to sync design request',
    });
  }
};
