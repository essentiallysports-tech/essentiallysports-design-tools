# Google Sheets Setup

The Design Request form now posts each successful request to:

`/.netlify/functions/design-request-submit`

That function appends a row to Google Sheets when these Netlify environment variables are set:

```text
GOOGLE_SHEETS_ID=1zKanDaGLj8xy9dEOLZwQH5fdRuQiqgPvYtP0CegzufU
GOOGLE_SHEETS_RANGE=Sheet1!A:V
GOOGLE_SERVICE_ACCOUNT_EMAIL=service-account-name@project-id.iam.gserviceaccount.com
GOOGLE_PRIVATE_KEY=-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n
```

`GOOGLE_SHEETS_RANGE` is optional if your tab is named `Sheet1`.

## Sheet Headers

The connected sheet currently uses the default tab named `Sheet1`. Row 1 has been set up with these headers:

```csv
Request ID,Created At,Status,Request Type,Requester Name,Requester Email,Department,Publication,Social Channel,Sport,Team or League,Title,Entities,Brief,Design Copy,Reference Links,Reference Files,Additional Notes,Priority,Design Needed By,Publish At,Source
```

## Google Access

1. Create or open the Google Sheet.
2. Create a Google Cloud service account.
3. Enable the Google Sheets API for that Google Cloud project.
4. Create a JSON key for the service account.
5. Share the Google Sheet with the service account email as an editor.
6. Add the JSON key values to Netlify environment variables:
   - `client_email` goes into `GOOGLE_SERVICE_ACCOUNT_EMAIL`.
   - `private_key` goes into `GOOGLE_PRIVATE_KEY`.

Keep the private key only in Netlify environment variables. Do not put it in `index.html`.
